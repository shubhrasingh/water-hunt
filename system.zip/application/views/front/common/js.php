    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAj9b_nyz33KEaocu6ZOXRgqwwUZkDVEAw"></script>
    <script src="<?php echo base_url(); ?>assets/front/js/map.js"></script>
    <script src="<?php echo base_url(); ?>assets/front/js/vendor/jquery-1.12.0.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/front/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/front/js/jquery.nivo.slider.pack.js"></script>
    <script src="<?php echo base_url(); ?>assets/front/js/waypoints.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/front/js/jquery.counterup.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/front/js/ajax-mail.js"></script>
    <script src="<?php echo base_url(); ?>assets/front/js/owl.carousel.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/front/js/jquery.magnific-popup.js"></script>
    <script src="<?php echo base_url(); ?>assets/front/js/style-customizer.js"></script>
    <script src="<?php echo base_url(); ?>assets/front/js/plugins.js"></script>
    <script src="<?php echo base_url(); ?>assets/front/js/main.js"></script>