    <link rel="shortcut icon" type="image/x-icon" href="<?php echo  base_url(); ?>assets/front/images/fav.png">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/front/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/front/css/core.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/front/css/shortcode/shortcodes.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/front/css/style.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/front/css/responsive.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/front/css/style-customizer.css"> 
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/front/css/water-hunt.css"> 
    <script src="<?php echo base_url(); ?>assets/front/js/vendor/modernizr-2.8.3.min.js"></script>