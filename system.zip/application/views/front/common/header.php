  <header class="header  header-2">
       <div class="header-top-1" style="background: #bed00d;">
                <div class="container">
                    <div class="row">
                        <div class="col-md-4 col-sm-4 hidden-xs">
                            <div class="haven-call">
                                <p><i class="fa fa-phone"></i> <?php echo $siteDetails['companyData'][0]->company_phone; ?></p>
                            </div>
                        </div>
                        <div class="col-md-8 col-sm-8 col-xs-12">
                            <div class="header-1-top-inner">
                                <div class="header-topbar-menu">
                                    <ul>
                                        <li><span><i class="fa fa-envelope"></i> </span> <?php echo $siteDetails['companyData'][0]->company_email; ?></li>
                                        <?php
                                        if(($this->session->userdata('WhUserLoggedinId')!="") && ($this->session->userdata('WhUserLoggedinId')!='0'))
                                        {
                                         $userId=$this->session->userdata('WhUserLoggedinId');
                                         $userType=$this->session->userdata('WhLoggedInUserType');
                                         switch($userType)
                                         {
                                            case "merchant":
                                               $folder="merchant";
                                            break;

                                            case "user":
                                               $folder="user";
                                            break;
                                         }
                                        ?>
                                           <li><a href="<?php echo base_url(); ?><?php echo $folder ?>"><i class="fa fa-user"></i>  Welcome <?php echo $userDetails[0]->name; ?></a></li>
                                           <li><a href="<?php echo base_url(); ?>logout"><i class="fa fa-lock"></i> Logout</a></li>
                                        <?php
                                        }
                                        else
                                        {
                                            ?>
                                           <li><a href="<?php echo base_url(); ?>login"><i class="fa fa-user"></i>  Login</a></li>
                                           <li><a href="<?php echo base_url(); ?>register"><i class="fa fa-user"></i> Register</a></li>
                                        <?php
                                        }
                                        ?>
                                    </ul>
                                </div>
                                <div class="header-search">
                                    <div class="search-icon">
                                        <a href="#"><i class="fa fa-search"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="header-top">
                <div class="container">
                    <div class="row">
                        <div class="col-md-2 col-sm-4 col-xs-6">
                            <div class="logo">
                                <a href="<?php echo base_url(); ?>"><img src="<?php echo  base_url(); ?>assets/front/uploads/logo/<?php echo $siteDetails['companyData'][0]->company_logo; ?>" alt=""></a>
                            </div>
                        </div>
                        <div class="col-md-10 hidden-sm hidden-xs">
                            <div class="mgea-full-width">
                                <div class="header-menu">
                                    <nav>
                                        <ul>
                                            <li><a href="<?php echo base_url(); ?>">Home</a></li>
                                            <li><a href="#">About Us</a></li>
                                            <li><a href="#"> Water Park</a>
                                                <ul class="dropdown_menu">
                                                    <li><a href="#">Nilansh Theme Park</a></li>
                                                    <li><a href="#">Anadi Water Park</a></li>
                                                    <li><a href="#">Disney Water Wonder park</a></li>
                                                    <li><a href="#">Diamond Aqua Park</a></li>
                                                </ul>
                                            </li>
                                            <li><a href="#">Events</a></li>
                                            <li><a href="#">Services</a></li>
                                            <li><a href="#"> Contact Us</a></li>
                                           
                                        </ul>
                                    </nav>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="mobile-menu-area hidden-lg hidden-md">
                    <div class="container">
                        <div class="col-md-12">
                            <nav id="dropdown">
                                <ul>
                                    <li><a href="<?php echo base_url(); ?>">Home</a></li>
                                    <li><a href="#">About Us</a></li>
                                    <li><a href="#"> Water Park</a>
                                        <ul class="dropdown_menu">
                                            <li><a href="#">Nilansh Theme Park</a></li>
                                            <li><a href="#">Anadi Water Park</a></li>
                                            <li><a href="#">Disney Water Wonder park</a></li>
                                            <li><a href="#">Diamond Aqua Park</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="#">Events</a></li>
                                    <li><a href="#">Services</a></li>
                                    <li><a href="#"> Contact Us</a></li>
                                    <li><a href="<?php echo base_url(); ?>login">Login</a></li>
                                    <li><a href="<?php echo base_url(); ?>register">Register</a></li>
                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <div class="header-bottom">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <div class="haven-call">
                                <p>+91 8126707732</p>
                            </div>
                            <div class="add-property">
                                <a href="#" style="background:#bed00d none repeat scroll 0 0">ADD WATER PARK</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!--Search box inner start-->
            <div class="search-box-area">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="search-form">
                                <div class="search-form-inner">
                                    <form action="#">
                                        <input type="text" placeholder="Search..">
                                        <button type="submit"><i class="icofont icofont-search-alt-1"></i></button>
                                    </form>
                                </div>
                                <div class="search-close-btn">
                                    <a href="#"><i class="zmdi zmdi-close"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--Search box inner end-->
        </header>