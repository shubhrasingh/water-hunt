<footer class="footer wow fadeIn" data-wow-duration="1.3s" data-wow-delay="0.5s">
           <div class="footer-bottom">
                <div class="container">
                    <div class="row">
                        <div class="col-md-7 col-sm-12 col-xs-12">
                            <div class="footer-menu">
                                <ul>
                                    <li><a href="#">Home</a></li>
                                    <li><a href="#">About Us</a></li>
                                    <li><a href="#">Services</a></li>
                                    <li><a href="#">Contact Us</a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-md-5 col-sm-12 col-xs-12">
                            <div class="copyright">
                                <p>Copyright <i class="fa fa-copyright"></i> 2019 <a  href="#">Water Hunt</a>. All rights reserved.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
         </footer>